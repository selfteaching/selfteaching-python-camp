收获总结：完成自学任务，很重要的一点是找到需要的工具和资料，教练组针对作业内容提供了很多参考资料，在这一点上，节省了大量搜索的精力和时间。但是面对无人指导自学时，这一点却是非常重要的。
遇到的难点与问题：安装SourceTree软件过程中，需要连接Bitbucket的账户。没有的话可以用自己的邮箱注册一个，可能是由于网络原因，连不上Bitbucke账户，耽误了1个多小时。具体安装步骤可参考：https://confluence.atlassian.com/get-started-with-sourcetree/install-and-set-up-sourcetree-847359043.html
