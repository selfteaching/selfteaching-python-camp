# Day 1
### 1.在Github中直接添加文件，进入要编辑的branch,如图点击create new file
![](https://github.com/slona-song/selfteaching-python-camp/blob/master/19100105/slona-song/image/001.1.png)
### 2.下载使用Sourcetree
  - **时涉及到bitbucket的注册验证，可能由于是国外的网站，响应特别慢（可能存在着刷不出来的风险），于是直接开了加速器，顺利下载安装**
![下载完成](https://github.com/slona-song/selfteaching-python-camp/blob/master/19100105/slona-song/image/001.2.png)
  - **使用URL进行克隆**
![使用URL进行克隆](https://github.com/slona-song/selfteaching-python-camp/blob/master/19100105/slona-song/image/001.3.png)
  - **克隆结果**
![](https://github.com/slona-song/selfteaching-python-camp/blob/master/19100105/slona-song/image/001.4.png)
  - **默认自动语言是中文，为了统一我修改了语言，English看着更舒服**
![](https://github.com/slona-song/selfteaching-python-camp/blob/master/19100105/slona-song/image/001.5.png)
  - **在本地仓库创建文件,采用了手动上传的方法，sourcetree中也能够同步显示**
![](https://github.com/slona-song/selfteaching-python-camp/blob/master/19100105/slona-song/image/001.6.png)
