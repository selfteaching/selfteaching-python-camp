# 自学 Python 入门训练营 001期05班

# 教练

[@zrmqfdy](https://github.com/zrmqfdy)

# 学员

[@guizhiwu](https://github.com/guizhiwu)

[@faqiang007](https://github.com/faqiang007)

[@quan0523](https://github.com/quan0523)

[@liuzhongjia](https://github.com/liuzhongjia)

[@slona-song](https://github.com/slona-song)

[@liwanlsl](https://github.com/liwanlsl)

[@baishanheishui](https://github.com/baishanheishui)

[@shuyushei](https://github.com/shuyushei)
