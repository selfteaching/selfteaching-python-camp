# 自学 Python 入门训练营 001期01班

# 教练

[@realcaiying](https://github.com/realcaiying)

# 学员

[@xiaoguaishou01](https://github.com/xiaoguaishou01)

[@WangRui0802](https://github.com/WangRui0802)

[@raoxin007](https://github.com/raoxin007)

[@YanHuiii](https://github.com/YanHuiii)

[@zhwycsz](https://github.com/zhwycsz)

[@qiming09](https://github.com/qiming09)

[@lidong2119](https://github.com/lidong2119)

[@shawnlth](https://github.com/shawnlth)

[@sundyyang](https://github.com/sundyyang)

[@echojce](https://github.com/echojce)