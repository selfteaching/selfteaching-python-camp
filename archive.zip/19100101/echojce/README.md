python exercise notes

2019.3.18
1. create an account of github.
2. create a repository named 'hello world'.
3. learn concept of branch and master.
4. pull request and merge content between branch and master.
5. use sourcetree tool to manage remote project.
6. commit changes of local to remote project.
