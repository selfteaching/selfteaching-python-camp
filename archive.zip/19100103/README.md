# 自学 Python 入门训练营 001期03班

# 教练

[srvz](https://github.com/srvz)

# 学员

[cobraorg](https://github.com/cobraorg)

[zdy958](https://github.com/zdy958)

[ljqbpm](https://github.com/ljqbpm)

[hono355](https://github.com/hono355)

[abnerLinchunliang](https://github.com/abnerLinchunliang)

[lucaslu0724](https://github.com/lucasLu0724)

[worldknowme](https://github.com/worldknowme)

[wleis2020](https://github.com/wleis2020)

[xiaopenglee](https://github.com/xiaopenglee)

[hzzxhn](https://github.com/hzzxhn)
