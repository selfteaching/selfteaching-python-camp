# 自学 Python 入门训练营 001期04班

# 教练

[@zrmqfdy](https://github.com/zrmqfdy)

# 学员

[@Jacquesxu666](https://github.com/Jacquesxu666)

[@imjingjingli](https://github.com/imjingjingli)

[@Rocky198911](https://github.com/Rocky198911)

[@gglibiao](https://github.com/gglibiao)

[@zqiwj](https://github.com/zqiwj)

[@tuduier](https://github.com/tuduier)

[@fan101105](https://github.com/fan101105)

[@coldinmoon](https://github.com/coldinmoon)

[@fuzaifei](https://github.com/fuzaifei)

[@somedaykevin](https://github.com/somedaykevin)
