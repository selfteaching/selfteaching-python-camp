# 自学 Python 入门训练营 001期04班

# 教练

[@zrmqfdy](https://github.com/zrmqfdy)

# 学员