# 自学 Python 入门训练营 001期02班

# 教练

[srvz](https://github.com/srvz)

# 学员

[jinjin1111](https://github.com/jinjin1111)

[daweijian](https://github.com/daweijian)

[lipeer](https://github.com/lipeer)

[hpreborn](https://github.com/hpreborn)

[jynbest6066](https://github.com/jynbest6066)

[liyiting2019](https://github.com/liyiting2019)

[wengyadong](https://github.com/wengyadong)

[yxxyes](https://github.com/yxxyes)

[jinliang20190315](https://github.com/jinliang20190315)

[wayfuturecn](https://github.com/wayfuturecn)
